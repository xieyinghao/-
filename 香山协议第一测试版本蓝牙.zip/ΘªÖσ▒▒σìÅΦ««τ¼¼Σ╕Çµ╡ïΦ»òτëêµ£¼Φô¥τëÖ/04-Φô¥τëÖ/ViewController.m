//
//  ViewController.m
//  04-蓝牙
//
//  Created by vera on 16/10/14.
//  Copyright © 2016年 deli. All rights reserved.
//

#import "ViewController.h"
#import "BlueToothManager.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    //设置扫描成功的回调
    [manager setBlueToothDidScanPeripheralsCallback:^(NSArray *peripherals) {
        
        [self handleSacnPeripherals:peripherals];
        
    }];
    //扫描
    [manager scan];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [btn setTitle:@"设置闹钟" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor grayColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(sendData) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(100, 210, 100, 100)];
    [btn1 setTitle:@"设置时间" forState:UIControlStateNormal];
    btn1.backgroundColor = [UIColor grayColor];
    [self.view addSubview:btn1];
    [btn1 addTarget:self action:@selector(sendtime) forControlEvents:UIControlEventTouchUpInside];
    
}
#pragma =========================连接外部设备====================================================================
///连接外部设备
- (void)handleSacnPeripherals:(NSArray *)peripherals
{
    BlueToothManager *manager = [BlueToothManager shareManager];
    
    __weak BlueToothManager *weakManager = manager;
    
    //扫描到外部设备
//    CBPeripheral *peripheral = peripherals.firstObject;
    for (CBPeripheral *peripheral in peripherals) {
     
        //连接外部设备
//        93C2EA18-D812-40BE-8E24-BCB6D4AE65F4
//        8E051A78-2D88-4601-9763-65C89D261F6B  残废的
//         空升 67A4944A-CF24-4667-8474-35F2A6A19429
        if ([peripheral.identifier.UUIDString isEqualToString:@"93C2EA18-D812-40BE-8E24-BCB6D4AE65F4"]) {
            
            [weakManager connect:peripheral];
            
        }
        
    }
    
    
}
#pragma =========================app发送获得闹钟请求================================
/**
 发送数据
 */
- (void)sendData
{
    NSString *uuid = @"0AF6";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备电池信息 (command_id 为 0x02, key 为 0x01)
     
     */
    
//    <07010600 00000000 00000000 00000000 00000000>  自拍的返回指令
//    <07010200 00000000 00000000 00000000 00000000>  音乐暂停与播放
//    <07010400 00000000 00000000 00000000 00000000>  音乐播放上一首
//    <07010500 00000000 00000000 00000000 00000000>  音乐播放下一首
    
    //设置闹钟   03  02 8（0~8） 01开 15点 59 分  fe全开
    Byte byte[20];
    byte[0] = 0X03;
    byte[1] = 0x02;
    byte[2] = 5;
    byte[3] = 0x01;
    byte[4] = 16;
    byte[5] = 49;
    byte[6] = 0xfe;
    byte[7] = 0;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"=UUID:%@======准备发送数据%@=======",uuid,data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];
    //设置接收硬件数据的回调
    [[BlueToothManager shareManager] setBlueToothDidUpdateValueCallback:^(CBCharacteristic *characteristic, NSData *value)
     {
         //处理结果
         [self handleValue:value];
    }];
}


/**
 处理硬件返回的数据

 @param data <#data description#>
 */
- (void)handleValue:(NSData *)data
{
    NSLog(@"===========返回的数据%@",data);
    Byte *byte = (void *)data.bytes;
    
    //command_id
    Byte command_id = byte[0];
    //key
    Byte key = byte[1];
    
    //获得设备基本信息
    if (command_id == 0x02 && key == 0x03)
    {
        //固件版本号
        //固件版本号
        Byte b[] = {byte[2]};
        NSData *adata = [[NSData alloc] initWithBytes:b length:sizeof(b)];
        NSString *str = [adata ConvertToNSString];
        UInt64 weight = strtoul([str UTF8String], 0, 16);
        NSLog(@"===========数据！！！！%@",weight);
    }

}
#pragma =========================app发送获得设置时间请求================================
-(void)sendtime
{
    
    NSString *uuid = @"0AF6";
    
    /*
     20字节
     
     //数据包格式：
     command_id(1个字节)  key(1个字节)  value(18个字节)
     
     获得设备电池信息 (command_id 为 0x02, key 为 0x01)
     
     */
    
    //    <07010600 00000000 00000000 00000000 00000000>  自拍的返回指令
    //    <07010200 00000000 00000000 00000000 00000000>  音乐暂停与播放
    //    <07010400 00000000 00000000 00000000 00000000>  音乐播放上一首
    //    <07010500 00000000 00000000 00000000 00000000>  音乐播放下一首
    
    //设置闹钟   03  02 8（0~8） 01开 15点 59 分  fe全开
    Byte byte[20];
    byte[0] = 0X03;
    byte[1] = 0x01;
    byte[2] = 16;
    byte[3] = 12;
    byte[4] = 29;
    byte[5] = 16;
    byte[6] = 48;
    byte[7] = 0;
    byte[8] = 0x00;
    byte[9] = 0x00;
    byte[10] = 0x00;
    byte[11] = 0x00;
    byte[12] = 0x00;
    byte[13] = 0x00;
    byte[14] = 0x00;
    byte[15] = 0x00;
    byte[16] = 0x00;
    byte[17] = 0x00;
    byte[18] = 0x00;
    byte[19] = 0x00;
    NSData *data = [NSData dataWithBytes:byte length:20];
    NSLog(@"=UUID:%@======准备发送时间数据%@=======",uuid,data);
    //获得设备基本信息
    [[BlueToothManager shareManager] writeData:data characteristicUUIDString:uuid type:CBCharacteristicWriteWithResponse];

    
}
@end
